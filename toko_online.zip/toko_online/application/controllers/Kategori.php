<?php

class Kategori extends CI_Controller{
    public function sepatu_vans()
    {
        $data['sepatu_vans'] = $this->model_kategori->data_sepatu_vans()->result();

        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('Sepatu_vans',$data);
        $this->load->view('templates/footer');
    }

    public function sepatu_nike()
    {
        $data['sepatu_nike'] = $this->model_kategori->data_sepatu_nike()->result();

        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('Sepatu_nike',$data);
        $this->load->view('templates/footer');
    }

    public function sepatu_adiddas()
    {
        $data['sepatu_adiddas'] = $this->model_kategori->data_sepatu_adiddas()->result();

        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('Sepatu_adiddas',$data);
        $this->load->view('templates/footer');
    }

    public function sepatu_converse()
    {
        $data['sepatu_converse'] = $this->model_kategori->data_sepatu_converse()->result();

        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('Sepatu_converse',$data);
        $this->load->view('templates/footer');
    }
}