<?php 

class Riwayat extends CI_Controller{
    public function __construct(){
        parent::__construct();

        if($this->session->userdata('role_id') !='2'){
            $this->session->set_flashdata('pesan','<div class="alert alert-danger alert-dismissible fade show" role="alert">
            Anda Belum Login!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>');
          redirect('auth/login');
        }
    }

    public function index(){
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('Riwayat');
        $this->load->view('templates/footer'); 
    }

    public function upload(){
        $id = $this->input->post('id');
        $bukti = $_FILES['bukti']['name'];
        if ($bukti){
            $config ['upload_path'] ='./uploads/bukti/';
            $config ['allowed_types'] ='jpg|png|jpeg';

            $this->load->library('upload', $config);
            if($this->upload->do_upload('bukti')){
                $bukti = $this->upload->data('file_name');
            }else {
                echo "Gambar Gagal di Upload!";
            }
        }else{
            echo "Gambar Gagal di Upload!";
        }

        $this->db->set('bukti', $bukti);
        $this->db->where('id', $id);
        $this->db->update('tb_pesanan');

        redirect('Riwayat');
    }

    public function rating(){
        $data = [
            'id_pesanan' => $this->input->post('id_pesanan'),
            'id_user' => $this->session->userdata('id_user'),
            'id_barang' => $this->input->post('id_barang'),
            'rating' => $this->input->post('rating')
        ];
            $this->db->insert('tb_rating', $data);
            redirect('Riwayat');
    }
}