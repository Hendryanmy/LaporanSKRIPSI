<?php

class Dashboard_admin extends CI_Controller{
    
    public function __construct(){
        parent::__construct();

        if($this->session->userdata('role_id') !='1'){
            $this->session->set_flashdata('pesan','<div class="alert alert-danger alert-dismissible fade show" role="alert">
            Anda Belum Login!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>');
          redirect('auth/login');
        }
    }
    public function index()
    {
        $data['barang'] = $this->Model_dashboard->barang();
        $data['uang'] = $this->Model_dashboard->uang();
        $data['tahun'] = $this->Model_dashboard->gettahun();
        $this->load->view('templates_admin/header');
        $this->load->view('templates_admin/sidebar');
        $this->load->view('admin/Dashboard', $data);
        $this->load->view('templates_admin/footer');
    }

    public function filter(){
      
      
      $tahun = $this->input->post('tahun');
      $nilaifilter = $this->input->post('nilaifilter');

      if($nilaifilter = 1) {

        $data['title'] ="Laporan Penjualan By Tahun";
        $data['subtitle'] =$tahun;
        $data['datafilter'] = $this->Model_dashboard->filterbytahun($tahun);
        

        $this->load->view('admin/print_laporan', $data);
      }
    }
  }