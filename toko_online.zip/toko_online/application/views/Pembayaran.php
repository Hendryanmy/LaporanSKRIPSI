<div class="container-fluid">
    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <div class="btn btn-sm btn-danger">
                <?php $grand_total = 0;
                if ($keranjang = $this->cart->contents())
                {
                    foreach ($keranjang as $item)
                    {
                        $grand_total = $grand_total + $item['subtotal'];
                    }
                    echo "<h4>Total Belanja Anda: Rp. ".number_format($grand_total, 0,',','.' );
                 ?> + Ongkir Rp. 20.000
            </div><br><br>
            <h3>Input Alamat Pengiriman dan Pembayaran</h3>
            <form method="post" action="<?php echo base_url() ?>dashboard/proses_pesanan">

            <div class="form-group">
                <label>Nama Lengkap</label>
                <input type="text" name="nama" placeholder="Nama Lengkap" class="form-control" value="<?= $this->session->userdata('nama');?>" readonly>
            </div>

            <div class="form-group">
                <label>No. Telepon / WhatsApp</label>
                <input type="text" name="no_telp" placeholder="Nomor Telepon Anda" class="form-control">
            </div>

            <div class="form-group">
                <label>Alamat Lengkap</label>
                <input type="text" name="alamat" placeholder="Alamat Lengkap Anda" class="form-control">
            </div>

            <div class="form-group">
                <label>Kabupaten</label>
                <select class="form-control">
                    <option>Kabupaten Bandung</option>
                    <option>Kabupaten Bandung Barat</option>
                    <option>Kabupaten Bekasi</option>
                    <option>Kabupaten Bogor</option>
                    <option>Kabupaten Ciamis</option>
                    <option>Kabupaten Cianjur</option>
                    <option>Kabupaten Cirebon</option>
                    <option>Kabupaten Garut</option>
                    <option>Kabupaten Indramayu</option>
                    <option>Kabupaten Karawang</option>
                    <option>Kabupaten Kuningan</option>
                    <option>Kabupaten Majalengka</option>
                    <option>Kabupaten Pangandaran</option>
                    <option>Kabupaten Purwakarta</option>
                    <option>Kabupaten Subang</option>
                    <option>Kabupaten Sukabumi</option>
                    <option>Kabupaten Sumedang</option>
                    <option>Kabupaten Tasikmalaya</option>
                    
                </select>
            </div>

            <div class="form-group">
                <label>Kota</label>
                <select class="form-control">
                    <option>Kota Bandung</option>
                    <option>Kota Banjar</option>
                    <option>Kota Bekasi</option>
                    <option>Kota Bogor</option>
                    <option>Kota Cimahi</option>
                    <option>Kota Cirebon</option>
                    <option>Kota Depok</option>
                    <option>Kota Sukabumi</option>
                    <option>Kota Tasikmalaya</option>
                </select>
            </div>

            <div class="form-group">
                <label>Pilih BANK</label>
                <select class="form-control">
                    <option>BRI - 3370886821</option>
                    <option>BCA - 3370886821</option>
                </select>
            </div>

            <div class="form-group">
                <label>Pilih UKURAN</label>
                <select class="form-control" name="ukuran">
                    <option>39</option>
                    <option>40</option>
                    <option>41</option>
                    <option>42</option>
                    <option>43</option>
                    <option>44</option>
                    <option>45</option>
                </select>
            </div>

            <button type="submit" class="btn btn-sm btn-primary mb-3">Pesan</button>
            <a href="<?php echo base_url('dashboard/detail_keranjang') ?>"><div class="btn btn-sm btn-success mb-3">Kembali</div></a>
        
            </form>
            <?php
                }else{
                    echo "<h4>Keranjang Belanja Anda Masih Kosong";
                }
            ?>
        </div>
        
        <div class="col-md-2"></div>
    </div>
</div>