<div class="container-fluid">
    <div class="alert alert-danger">
        <p class="text-center align-middle">Selamat Pesanan Anda Sudah Masuk ! Jika Pesanan Anda Ingin di Proses Maka lanjut ke Riwayat Belanja Untuk Menyertakan Bukti Transfer Sesuai Total Belanja dan Ongkir</p>
        <p class="text-center align-middle">Perhatikan Total Belanja dan Ongkir !</p>
    </div>
</div>