<?php
$id_user = $this->session->userdata('id_user');
$query = "SELECT *
        FROM `tb_pesanan`
        JOIN `tb_invoice` ON `tb_pesanan`.`id_invoice` = `tb_invoice`.`id_invoice`
        WHERE `tb_invoice`.`id_user` = $id_user
        ";
$riwayat = $this->db->query($query)->result_array();
?>

<div class="container-fluid">
    <h4>Riwayat Pesanan</h4>

    <table class="table table-bordered table-hover table-striped">
        <tr>
            <th>Nama Barang</th>
            <th>Alamat Pengiriman</th>
            <th>Tanggal Pemesan</th>
            <th>Batas Pembayaran</th>
            <th>Batas Pengiriman</th>
            <th>Jumlah</th>
            <th>Harga</th>
            <th>Bukti Bayar</th>
            <th>Beri Rating</th>
        </tr>
        
        <?php foreach ($riwayat as $rwt): ?>
        <tr>
            <td><?php echo $rwt['nama_barang'] ?></td>
            <td><?php echo $rwt['alamat'] ?></td>
            <td><?php echo $rwt['tgl_pesan'] ?></td>
            <td><?php echo $rwt['batas_bayar'] ?></td>
            <td><?php echo $rwt['batas_pengiriman'] ?></td>
            <td><?php echo $rwt['jumlah'] ?></td>
            <td><?php echo $rwt['harga'] ?></td>
            <?php if($rwt['bukti']):?>
                <td><img src="<?php echo base_url('uploads/bukti/').$rwt['bukti'];?>" alt="" style="max-height: 50px;"></td>
            <?php else:?>
                <td>
                    <form action="<?php echo base_url().'riwayat/upload' ?>" method="post" enctype="multipart/form-data">
                    <input type="hidden" value="<?= $rwt['id'];?>" name="id">
                    <input type="file" name="bukti">
                    <button type="submit" class="btn btn-sm btn-primary">Upload</button>
                    </form>
                </td>
            <?php endif;?>
            <?php if($rwt['bukti']):?>
                <?php
                    $id_pesanan = $rwt['id'];
                    $cek = $this->db->query("SELECT * FROM tb_rating WHERE id_pesanan = $id_pesanan")->row_array();
                    ?>
                    <?php if($cek):?>
                    <td>Anda Sudah Memberi Rating</td>
                    <?php else:?>
                    <td>
                    <form action="<?php echo base_url().'riwayat/rating' ?>" method="post">
                    <input type="hidden" value="<?php echo $rwt['id'];?>" name="id_pesanan">
                    <input type="hidden" value="<?php echo $rwt['id_barang'];?>" name="id_barang">
                    <select name="rating" id="rating" name="rating" class="form-control-sm">
                        <option value="" selected hidden>Beri Rating</option>
                        <option value="1">Bintang 1</option>
                        <option value="2">Bintang 2</option>
                        <option value="3">Bintang 3</option>
                        <option value="4">Bintang 4</option>
                        <option value="5">Bintang 5</option>
                    </select>
                    <button type="submit" class="btn btn-sm btn-primary">Kirim</button>
                    </form>
                    </td>
                    <?php endif;?>
            <?php else:?>
                <td>Belum Upload Bukti</td>
            <?php endif;?>
        </tr>
        <?php endforeach; ?>
    </table>
</div>