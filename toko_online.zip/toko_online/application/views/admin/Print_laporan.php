<title>Print Laporan</title>
<body>
    <h1 style="text-align:center;"><?php echo $title ?> </h1>
    <h2 style="text-align:center;">Tahun: <?php echo $subtitle ?> </h2>

    <br>
    <br>
    <br>
    <table border="1" style="text-align:center; margin: 0 auto;">
        
            <tr>
                <th>No</th>
                <th>Id Invoice</th>
                <th>Id User</th>
                <th>Alamat</th>
                <th>Tanggal Pesan</th>
                <th>Jumlah</th>
            </tr>
        <tbody>
        <?php $no=1;
        foreach ($datafilter as $row): ?>
        
        
            <tr>
                    <td><?php echo $no++ ?></td>
                    <td><?php echo $row->id_invoice ?></td>
                    <td><?php echo $row->id_user ?></td>
                    <td><?php echo $row->alamat ?></td>
                    <td><?php echo $row->tgl_pesan ?></td>
                    <td><?php echo $row->harga ?> </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</body>