<?php

class Model_dashboard extends CI_Model{
    public function barang(){
        $query = $this->db->query("SELECT SUM(jumlah) AS total_barang FROM tb_pesanan");
        return $query->row();
    }

    public function uang(){
        $query = $this->db->query("SELECT SUM(harga) AS total_uang FROM tb_pesanan");
        return $query->row();
    }

    public function rating($id_brg){
        $query = $this->db->query("SELECT AVG(rating) AS rating FROM tb_rating WHERE id_barang = $id_brg");
        return $query->row();
    }
    public function gettahun(){
        $query = $this->db->query("SELECT YEAR(tgl_pesan) AS tahun FROM tb_invoice GROUP BY YEAR(tgl_pesan) ORDER BY YEAR(tgl_pesan) ASC");
    
        return $query->result();
    }
    public function filterbytahun($tahun){
        $query = $this->db->query("SELECT tb_invoice.*, tb_pesanan.*, tb_user.*
        FROM tb_invoice
        INNER JOIN tb_pesanan ON tb_invoice.id_invoice = tb_pesanan.id_invoice
        INNER JOIN tb_user ON tb_invoice.id_user = tb_user.id
        WHERE YEAR(tgl_pesan)=$tahun ORDER BY tgl_pesan ASC");

        return $query->result();

        $query = $this->db->query("SELECT SUM(harga) AS total_uang FROM tb_pesanan");
        return $query->row();
    }
}