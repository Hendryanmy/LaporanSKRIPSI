<?php

class Model_kategori extends CI_Model{

    public function data_sepatu_vans(){
        return $this->db->get_where('tb_barang',array('kategori' => 'sepatu vans'));
    }

    public function data_sepatu_nike(){
        return $this->db->get_where('tb_barang',array('kategori' => 'sepatu nike'));
    }

    public function data_sepatu_adiddas(){
        return $this->db->get_where('tb_barang',array('kategori' => 'sepatu adiddas'));
    }

    public function data_sepatu_converse(){
        return $this->db->get_where('tb_barang',array('kategori' => 'sepatu converse'));
    }
}